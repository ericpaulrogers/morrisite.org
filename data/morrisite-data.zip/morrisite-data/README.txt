Morrisite.org data files
========================

Release 1.4, November 24, 2026.

License: Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/
You may copy, adapt and republish these files for any purpose, with credit to Morrisite.org.

Cite as: Rogers, Eric Paul, ed. Morrisite.org Data. Release 1.4, November 24, 2026. https://doi.org/10.5281/zenodo.24521508.

From https://morrisite.org/data.html. Rebuilt with each update of the site.
Before you count: the roll is not a full list of members; sex and name origin are judged from names alone;
facts drawn from FamilySearch Family Tree come from a shared, editable tree; a blank means not yet found, not none.

Methods and definitions
-----------------------

What each file counts.
  The roll file has one row for each name printed on the 1886 roll; the whereabouts file one row for each record that places a person from the roll somewhere after 1862; the relationships file one row for each family tie between two people on the roll; the others-named file one row for each person outside the roll whom a source names as a Morrisite or as a follower of a later offshoot; and the posse file one row for each name on the militia returns. A row is a name or a record, not a household, and a person may have many rows in the whereabouts file.

Who is included.
  The roll is the list of the Church of the Firstborn printed by George S. Dove & Co. in 1886 from the 1861–62 record: 430 names, taken as printed, with nothing added or removed. It is not a complete count of everyone who followed Morris; some who are known from other sources to have been at Kington Fort are not on it. A person is added to others named only when a source calls them a Morrisite (or a member of Morris’s church, of the Montana church, or of the Davies community) or records them as held or tried after the siege; family connection alone does not qualify, and living people are never included. The posse file lists the men on the returns, who were not Morrisites.

Three questions, kept apart.
  Three things are judged separately, and confidence in one is not carried over to another. Identity: is the person in a record the person on the roll? This is what familysearch_id records and what the certainty columns of the whereabouts and relationships files measure. Membership: was the person a Morrisite? For the roll, the roll itself is the evidence; for others named, the certainty column marks doubt about membership as well as identity. A particular fact: how well is a date, place or relationship supported? Each whereabouts row and each relationship carries its own source, and a sure identification does not make every date attached to the person sure.

Where each column comes from.
  Taken from the printed roll: roll_name. Judged by the editor from the name alone: sex_from_name and name_origin, which are not evidence of sex or birthplace. Taken from FamilySearch Family Tree, a shared, editable tree, as pulled on November 3, 2026 and updated where noted: familysearch_id, familytree_name, born, birthplace, died, death_place, company and company_year, and most relationships. These are leads: check the records attached in the tree. Taken from records read for this guide and cited row by row: the whereabouts, later_affiliation, the others-named summaries and the posse.

What a blank means.
  A blank means not yet found, never “none.” A blank familysearch_id does not mean no match exists, and a blank later_affiliation does not mean the person stayed in or left any church. Where sources conflict, the person’s page or the summary says so; the files give the reading the guide follows.

Known gaps.
  The records favor men, heads of households, leaders and the Montana congregation, and English names are matched more easily than Danish and Swedish ones. Most entries after 1900 are death records, so the files show where people died more than where they lived. Many members who went back to the Latter-day Saints left little trace as Morrisites. Counts made from these files reflect the surviving records as much as the movement.

Corrections.
  Corrections are made in the files as soon as they are found and are listed, with the release number, under Changes between releases. Each numbered release is kept unchanged so that a figure can be checked against the release it came from. Please send corrections and identifications to contact@morrisite.org.

morrisite-roll-1861-62.csv: The roll of membership, 1861–62
  One row for each of the 430 names on the roll printed by George S. Dove & Co. in 1886, with what the guide has added.
  - roll_name: The name as printed on the roll. A repeated name takes its order on the roll in brackets, e.g. Hanson, Rasmus [1].
  - sex_from_name: F or M, judged from the given name alone; blank if unclear.
  - name_origin: Scandinavian, English-language, German or Swiss, or Unclear, judged from the name alone. Not evidence of birthplace.
  - familysearch_id: The FamilySearch Family Tree person matched to this name, where a match has been made. Blank does not mean no match exists.
  - familytree_name: The name and dates in Family Tree.
  - born, birthplace, died, death_place: From Family Tree, as pulled on November 3, 2026. Family Tree is a shared, editable tree; check the sources attached there.
  - company, company_year: The pioneer company the person crossed the plains with, from the records attached in Family Tree.
  - later_affiliation: Where the person is known to have gone in religion after 1862. Blank means not yet known.
  - person_page: The guide’s page for the person, if there is one.

morrisite-whereabouts.csv: Where they went
  Documented whereabouts of people on the roll after 1862: the data behind the Where they went map.
  - roll_name: As on the roll.
  - year: The year of the record.
  - place: The place, as named on the map.
  - latitude, longitude: The map point for the place (approximate for towns and valleys).
  - certainty: Identity confidence: whether the person in the record is the person on the roll. sure: the record names the person and fits what is known; probable: the identification is likely but not proven (a common name, or a match by family and place); possible: one plausible candidate among others, kept for further research.
  - kind: The type of record: census, list (a membership or other list), testimony, patent (a federal land patent), death (a death, burial or probate record), marriage, letter, or note (a statement in a published or manuscript source).
  - source: Where the record is, with page or image where known.

morrisite-relationships.csv: Family ties on the roll
  Parent, spouse and sibling relationships between people on the roll, mostly from Family Tree.
  - person, relationship, other_person: Read as a sentence: A is the parent of / spouse of / sibling of / inlaw of (in-law of) B. Both people are on the roll.
  - familysearch_id, other_familysearch_id: The Family Tree IDs of the two people.
  - source: Where the relationship comes from. Most are from FamilySearch Family Tree, a shared, editable tree: treat them as leads and check the sources attached there.
  - certainty: confident when both people are firmly identified and the relationship is supported by records beyond the tree (a census, an emigration register, an obituary); probable when either person is a probable match or the relationship rests on the tree alone.
  - note: Any qualification.

morrisite-others-named.csv: Others named as Morrisites
  People the sources name as Morrisites, or as followers of a later offshoot, who are not on the printed roll. Deceased people only.
  - name: Surname first.
  - group: morris (Morris’s church), kington (held or tried after the siege), montana (the Deer Lodge church), or davies (the Walla Walla community).
  - earlier: earlier if known or said to have been with the Morrisites before joining Davies.
  - dates: As known.
  - what_the_sources_say: The guide’s summary.
  - source: The citation.
  - certainty: Blank when a source names the person as a Morrisite (or a follower of the offshoot) and the identification is secure; probable when either the identification of the person or the membership itself is uncertain. The summary says which.

morrisite-posse-1862.csv: The posse, June 1862
  The men named in the militia returns of the posse that besieged Kington Fort, June 12–18, 1862: the rolls of the Davis and Weber companies and the summary report kept by Deputy Marshal Theodore McKean (“Militia companies’ reports,” Theodore McKean family collection, MS 33041, Church History Library). These are the posse, not Morrisites. Transcribed for this guide from the page images; many names are hard to read, and some companies appear twice (a draft and a fair copy), so a man may appear more than once. See the posse chart.
  - image: The image number in the catalog’s digital copy.
  - unit: The company or command, as the return describes it.
  - role: Rank or duty where given (captain, lieut., sergeant, teamster), or the number on the roll.
  - name: As written; [?] marks an uncertain reading.
  - note: Horses, wagons, arms or other details on the return, and the editor’s identifications.
  - reading: uncertain when any part of the name is an uncertain reading.

Changes
-------
1.0 (November 10, 2026): First release: the roll (430 names), whereabouts after 1862, family ties on the roll, and others named as Morrisites.
1.1 (November 11, 2026): Correction: John Peter Lorensen’s death year (1870) and place (Nevada) removed from the roll and whereabouts files; Family Tree gives only “before 1870, probably Nevada,” and the 1870 census finds his family in Nevada without him. Others named: George Johnson’s birth (Denmark, 1856) added from a 1902 biography.
1.2 (November 12, 2026): Others named: four people added from the Council Bluffs and Omaha registers of 1869–72 (Church History Library, MS 32226): Anders and Karen Søndermark and Hans Knudsen, baptized at South Weber in 1861, and Carleton Fellows; entries for Joseph Morris, Andrew Hendrikson, and Isabella and James Bowman expanded from the registers and the Hendrickson letters. Correction: George Williams’s entry no longer says he prophesied in 1879 that Deer Lodge County would be the site of the Second Coming. Roll: Josiah Price’s later affiliation (Reorganized Church) added.
1.3 (November 21, 2026): New file: the posse of June 1862 (morrisite-posse-1862.csv, 341 entries from the militia returns, Church History Library, MS 33041). Whereabouts: 23 places added from the Council Bluffs and Omaha registers of 1869–72, the Montana Stake No. 2 record of 1874, and letters (Eardley at Stockport, 1873, and Salinas, 1878; W. P. Thomas in England, 1869; Josiah Price in Idaho, 1867). Others named: ten people added (Lars P., Maria and Nels J. Beck, Johan Helström, Niels Jensen, Peter Nielsen, Niels Thorkelsen and Emanuel Strom of the Omaha and Montana congregations; Rees Howels and John Morris, Welshmen at Kington Fort in May 1862); Joseph Morris’s birth date (December 15, 1823) added. Roll: four members of the Hanson and Christofferson families now shown as later joining the RLDS Church.
1.4 (November 24, 2026): Documentation: a new section, Methods and definitions, sets out what each file counts, what qualifies a person for it, how the certainty values are defined (keeping apart whether a record is the right person, whether that person was a Morrisite, and how well a particular fact is supported), what a blank means, where each column comes from, and the known gaps; a machine-readable data dictionary (morrisite-data-dictionary.csv) is added. Certainty values now documented as used: possible in the whereabouts file and confident in the relationships file, and the record kinds letter and marriage. Roll: Moses Byrne and his wives Catherine Cardon and Anne Beus matched in Family Tree; later affiliations added for Winter Hastings, Soren and Anne M. Willadson (RLDS), and S. P. and Maren Guhl (Morrisite, later RLDS); links to new person pages. Whereabouts: places added from the Saints’ Herald, censuses and Family Tree, including Winter Hastings (Springfield, Illinois, 1870; Gilman, Washington, 1891; Lamoni, Iowa, 1907–15), the Willadsons near Burlington, Iowa, the Byrnes at Piedmont, Wyoming, the Guhls at Council Bluffs (1876), L. Bar in Missouri (1871), Mahlon Chase in Montana (1887) and Margaret Cook in Carson Valley (1874). Relationships: Moses Byrne’s two marriages. Others named: James Bowman’s dates (1816–1903) and fuller entries for Andrew Hendrikson, Peter Staffanson, Emanuel Strom and Johan Helström.

