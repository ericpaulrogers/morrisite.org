Morrisite.org data files
========================

Release 1.1, November 11, 2026.

License: Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/
You may copy, adapt and republish these files for any purpose, with credit to Morrisite.org.

Cite as: Rogers, Eric Paul, ed. Morrisite.org Data. Release 1.1, November 11, 2026. https://doi.org/10.5281/zenodo.24100262.

From https://morrisite.org/data.html. Rebuilt with each update of the site.
Before you count: the roll is not a full list of members; sex and name origin are judged from names alone;
facts drawn from FamilySearch Family Tree come from a shared, editable tree; a blank means not yet found, not none.

morrisite-roll-1861-62.csv: The roll of membership, 1861–62
  One row for each of the 430 names on the roll printed by George S. Dove & Co. in 1886, with what the guide has added.
  - roll_name: The name as printed on the roll. A repeated name takes its order on the roll in brackets, e.g. Hanson, Rasmus [1].
  - sex_from_name: F or M, judged from the given name alone; blank if unclear.
  - name_origin: Scandinavian, English-language, German or Swiss, or Unclear, judged from the name alone. Not evidence of birthplace.
  - familysearch_id: The FamilySearch Family Tree person matched to this name, where a match has been made. Blank does not mean no match exists.
  - familytree_name: The name and dates in Family Tree.
  - born, birthplace, died, death_place: From Family Tree, as pulled on November 3, 2026. Family Tree is a shared, editable tree; check the sources attached there.
  - company, company_year: The pioneer company the person crossed the plains with, from the records attached in Family Tree.
  - later_affiliation: Where the person is known to have gone in religion after 1862. Blank means not yet known.
  - person_page: The guide’s page for the person, if there is one.

morrisite-whereabouts.csv: Where they went
  Documented whereabouts of people on the roll after 1862: the data behind the Where they went map.
  - roll_name: As on the roll.
  - year: The year of the record.
  - place: The place, as named on the map.
  - latitude, longitude: The map point for the place (approximate for towns and valleys).
  - certainty: sure, or probable when the identification of the person is likely but not proven.
  - kind: census, list, testimony, patent, death or note.
  - source: Where the record is.

morrisite-relationships.csv: Family ties on the roll
  Parent, spouse and sibling relationships between people on the roll, mostly from Family Tree.
  - person, relationship, other_person: Read as a sentence: A is the parent of / spouse of / sibling of B.
  - familysearch_id, other_familysearch_id: The Family Tree IDs of the two people.
  - source: Where the relationship comes from.
  - certainty: probable if either person is a probable match.
  - note: Any qualification.

morrisite-others-named.csv: Others named as Morrisites
  People the sources name as Morrisites, or as followers of a later offshoot, who are not on the printed roll. Deceased people only.
  - name: Surname first.
  - group: morris (Morris’s church), kington (held or tried after the siege), montana (the Deer Lodge church), or davies (the Walla Walla community).
  - earlier: earlier if known or said to have been with the Morrisites before joining Davies.
  - dates: As known.
  - what_the_sources_say: The guide’s summary.
  - source: The citation.
  - certainty: probable when the identification or membership is uncertain.

Changes
-------
1.0 (November 10, 2026): First release: the roll (430 names), whereabouts after 1862, family ties on the roll, and others named as Morrisites.
1.1 (November 11, 2026): Correction: John Peter Lorensen’s death year (1870) and place (Nevada) removed from the roll and whereabouts files; Family Tree gives only “before 1870, probably Nevada,” and the 1870 census finds his family in Nevada without him. Others named: George Johnson’s birth (Denmark, 1856) added from a 1902 biography.

